$(function(){
	$(".listdemo").jCarouselLite({
		auto: 1000,
		speed: 500,
		visible:5,
		scroll:5
	});
	$(".listdemo2 div").cqwoMarquee({
		auto: 1000,
		speed: 500,
		visible:5,
		scroll:5
	});
})
